from SOURCE_CODE_0307_VERSION_1.controller import game_controller,fake_controller
"""Run program from here!
"""
game_controller.GameController()

# fake_controller.FakeController()